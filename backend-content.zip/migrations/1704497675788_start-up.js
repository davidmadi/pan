/* eslint-disable camelcase */

exports.shorthands = undefined;

exports.up = pgm => {};

exports.down = pgm => {};
